# Slider like Yahoo Weather App

A Pen created on CodePen.io. Original URL: [https://codepen.io/fenixfgx/pen/ZEqJZNX](https://codepen.io/fenixfgx/pen/ZEqJZNX).

