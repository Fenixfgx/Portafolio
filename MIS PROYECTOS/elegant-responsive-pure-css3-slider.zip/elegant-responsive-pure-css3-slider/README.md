# Elegant Responsive Pure CSS3 Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/fenixfgx/pen/wvYYgXx](https://codepen.io/fenixfgx/pen/wvYYgXx).

Full Css no javascript