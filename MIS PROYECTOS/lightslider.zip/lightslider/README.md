# lightSlider

A Pen created on CodePen.io. Original URL: [https://codepen.io/fenixfgx/pen/eYPLjjN](https://codepen.io/fenixfgx/pen/eYPLjjN).

lightSlider demo