# Social bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/fenixfgx/pen/PoyOwwa](https://codepen.io/fenixfgx/pen/PoyOwwa).

Simple social bar