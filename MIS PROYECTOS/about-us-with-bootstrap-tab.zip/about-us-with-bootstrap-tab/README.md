# About us with bootstrap tab

A Pen created on CodePen.io. Original URL: [https://codepen.io/fenixfgx/pen/yLRowxm](https://codepen.io/fenixfgx/pen/yLRowxm).

Beautiful About us section made with bootstrap 3 with bootstrap tab and circular progress bar. Fully responsive and clean design.