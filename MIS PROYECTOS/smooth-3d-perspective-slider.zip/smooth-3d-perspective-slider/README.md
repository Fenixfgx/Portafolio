# Smooth 3d perspective slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/fenixfgx/pen/JjmmVXW](https://codepen.io/fenixfgx/pen/JjmmVXW).

Responsive (sort of?). Uses this technique for smooth transitions on mouse move - https://codepen.io/rachsmith/post/animation-tip-lerp